---
layout: default
title: 联系
permalink: /contact.html
---

# 联系方式（Contact）

- ✉️ you@example.com
- 🧭 学院/地址与邮编
- 🔗 学校主页链接

## 媒体素材
- `assets/images/` 放图片（PNG/JPG/SVG）
- `assets/videos/` 放小视频（不建议大文件；优先用外链平台）