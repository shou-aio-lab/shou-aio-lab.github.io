---
layout: default
title: 论文
permalink: /publications.html
---

# 论文（Publications）

- 2025 — **Paper Title**. *Journal Name*. [PDF](#) | [Code](#) | [Dataset](#)
- 2024 — **Paper Title**. *Journal Name*. [PDF](#)

> 可按年份分组，或用表格列出作者、期刊、DOI 等信息。