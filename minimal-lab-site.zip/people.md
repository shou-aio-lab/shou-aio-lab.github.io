---
layout: default
title: 成员
permalink: /people.html
---

# 成员（People）

## PI
**Dr. Your Name** — 研究方向：A、B、C  
邮箱：you@example.com · <a href="#">Google Scholar</a> · <a href="#">ORCID</a>

## 博后 & 学生
- **姓名 A**（博士生）— 方向：X、Y  
- **姓名 B**（硕士生）— 方向：P、Q

> 可将成员照片放置：`assets/images/name.jpg`，在 Markdown 中用 `![](assets/images/name.jpg)` 引用。