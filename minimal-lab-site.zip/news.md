---
layout: default
title: 新闻
permalink: /news.html
---

# 新闻（News）

- 2025-08-20：极简站点模板上线 🎉
- 2025-07-15：论文被 *Journal X* 接收。

> 直接以 Markdown 列表维护动态。